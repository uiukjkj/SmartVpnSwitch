# Smart VPN Switch (8849 Shark 3 / Android 14 / Kotlin)

Полноценное модульное Android-приложение (MVVM + Room + WorkManager + Coroutines + Jetpack Compose + Android VpnService).

## Архитектурные модули
- `engine`: `WireGuardEngine` (`com.wireguard.android:tunnel:1.0.20260102`, встроенный `GoBackend`) и `OpenVpnAidlEngine` (официальный AIDL IPC `de.blinkt.openvpn` / OpenVPN for Android).
- `discovery`: `VpnGateParser` (`https://www.vpngate.net/api/iphone/`), `ConfigValidator` (блокировка небезопасных директив `.ovpn` и строгая валидация WireGuard `Config.parse`), `ServerDiscoveryRepository`.
- `checker`: `ServerProbe` (реальный TCP RTT) и `PublicIpService` (проверка реального туннеля и внешнего IP через `ipwho.is` / `api.ipify.org`).
- `controller`: `SmartVpnController`, `ServerSelector`, `SmartVpnForegroundService` (`foregroundServiceType="specialUse"`), bounded failover (до 3 попыток).
- `buttons`: `Func1ToggleProxyActivity` (короткое нажатие Func1), `Func2NextServerProxyActivity` (долгое нажатие Func2), опциональный `OptionalButtonAccessibilityService`.
- `data`: Room Database (`vpn_servers`, `config_sources`, `connection_logs`), `KeystoreCrypto` (AES-256-GCM в AndroidKeyStore).
- `worker`: `ServerUpdateWorker` (WorkManager с ограничениями сети и заряда).

## Сборка готового APK без установки Android Studio (через GitHub Actions)
1. Загрузите папку `SmartVpnSwitch` (включая `.github/workflows/build-apk.yml`) в свой репозиторий GitHub.
2. Откройте вкладку **Actions** -> дождитесь завершения **Build SmartVpnSwitch APK**.
3. Скачайте `app-debug.apk` из раздела **Artifacts**.

## Настройка OpenVPN и кнопок на 8849 Shark 3
1. Для работы OpenVPN-конфигураций (включая VPNGate) установите **OpenVPN for Android** (`de.blinkt.openvpn`). WireGuard работает полностью встроенно.
2. В телефоне откройте **Настройки -> Shortcut settings**:
   - **Func1 (Single press)** -> `Smart VPN: Вкл/Выкл (FUNC1)`
   - **Func2 (Long press)** -> `Smart VPN: След. сервер (FUNC2)`
