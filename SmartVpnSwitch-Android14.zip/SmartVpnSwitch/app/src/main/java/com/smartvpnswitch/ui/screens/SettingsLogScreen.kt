package com.smartvpnswitch.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smartvpnswitch.ui.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsLogScreen(viewModel: MainViewModel) {
    val settings by viewModel.settings.collectAsState()
    val logs by viewModel.logs.collectAsState()
    val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Настройки обновления и VPN", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Автообновление (WorkManager, экономный режим)", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0 to "Вручную", 6 to "6 ч", 12 to "12 ч", 24 to "24 ч").forEach { (h, label) ->
                            FilterChip(
                                selected = settings.updateIntervalHours == h,
                                onClick = { viewModel.setUpdateIntervalHours(h) },
                                label = { Text(label) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Автопереподключение при обрыве", modifier = Modifier.weight(1f))
                        Switch(checked = settings.autoReconnect, onCheckedChange = { viewModel.setAutoReconnect(it) })
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Приоритет WireGuard при выборе", modifier = Modifier.weight(1f))
                        Switch(checked = settings.preferWireGuard, onCheckedChange = { viewModel.setPreferWireGuard(it) })
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Журнал подключений (${logs.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                TextButton(onClick = { viewModel.clearLogs() }) {
                    Text("Очистить")
                }
            }
        }

        items(logs, key = { it.id }) { entry ->
            val color = when (entry.level) {
                "SUCCESS" -> Color(0xFF10B981)
                "WARN" -> Color(0xFFF59E0B)
                "ERROR" -> Color(0xFFEF4444)
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            }
            Text(
                text = "[${timeFmt.format(Date(entry.timestamp))}] [${entry.level}] ${entry.message}",
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                color = color
            )
        }
    }
}
