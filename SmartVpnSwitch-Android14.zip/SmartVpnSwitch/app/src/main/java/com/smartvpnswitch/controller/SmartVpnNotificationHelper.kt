package com.smartvpnswitch.controller

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.smartvpnswitch.ui.MainActivity

object SmartVpnNotificationHelper {
    const val CHANNEL_ID = "smart_vpn_status"
    const val NOTIFICATION_ID = 4101

    fun ensureChannel(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        val existing = nm.getNotificationChannel(CHANNEL_ID)
        if (existing == null) {
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Состояние Smart VPN Switch",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Показывает статус подключения и переключения серверов"
                }
            )
        }
    }

    fun buildNotification(context: Context, title: String, content: String): Notification {
        ensureChannel(context)
        val openIntent = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(title)
            .setContentText(content)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .build()
    }

    fun updateNotification(context: Context, title: String, content: String) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.notify(NOTIFICATION_ID, buildNotification(context, title, content))
    }
}
