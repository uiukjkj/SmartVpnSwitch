package com.smartvpnswitch.ui

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartvpnswitch.SmartVpnApplication
import com.smartvpnswitch.data.ConfigSourceEntity
import com.smartvpnswitch.data.ConnectionLogEntity
import com.smartvpnswitch.data.SourceFormat
import com.smartvpnswitch.data.UserSettings
import com.smartvpnswitch.data.VpnProtocol
import com.smartvpnswitch.data.VpnServerEntity
import com.smartvpnswitch.engine.VpnRuntimeState
import com.smartvpnswitch.worker.ServerUpdateWorker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as SmartVpnApplication
    private val db = app.database
    private val prefs = app.preferences
    private val controller = app.vpnController

    val runtimeState: StateFlow<VpnRuntimeState> = controller.runtimeState
    val settings: StateFlow<UserSettings> = prefs.settings

    val servers: StateFlow<List<VpnServerEntity>> = db.serverDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sources: StateFlow<List<ConfigSourceEntity>> = db.sourceDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val logs: StateFlow<List<ConnectionLogEntity>> = db.logDao().observeRecent()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _uiBanner = MutableStateFlow<String?>(null)
    val uiBanner: StateFlow<String?> = _uiBanner.asStateFlow()

    private val _openVpnAppInstalled = MutableStateFlow(controller.openVpnEngine.isOpenVpnInstalled())
    val openVpnAppInstalled: StateFlow<Boolean> = _openVpnAppInstalled.asStateFlow()

    fun refreshCapabilities() {
        _openVpnAppInstalled.value = controller.openVpnEngine.isOpenVpnInstalled()
    }

    fun prepareVpnPermission(): Intent? = controller.prepareVpnPermissionIntent()

    fun toggleVpn() = controller.toggleVpn()

    fun connectServer(server: VpnServerEntity) = controller.connectSpecificServer(server)

    fun switchToNextServer() = controller.switchToNextServer()

    fun syncAndProbeServers() {
        if (_isSyncing.value) return
        viewModelScope.launch {
            _isSyncing.value = true
            try {
                val summary = app.discoveryRepository.syncAllEnabledSources()
                val reachable = app.serverProbe.probeServersBatch(limit = 30)
                controller.refreshPublicIpOutsideOrInside()
                _uiBanner.value = if (summary.errors.isEmpty()) {
                    "Обновлено: ${summary.serversDiscovered} серверов (доступно по TCP: $reachable)"
                } else {
                    "Частичное обновление (${summary.serversDiscovered}). Ошибки: ${summary.errors.joinToString()}"
                }
            } finally {
                _isSyncing.value = false
            }
        }
    }

    fun addSource(name: String, url: String, format: SourceFormat) {
        viewModelScope.launch {
            val res = app.discoveryRepository.addCustomSource(name, url, format)
            _uiBanner.value = res.fold(
                onSuccess = { "Источник добавлен" },
                onFailure = { "Ошибка: ${it.message}" }
            )
        }
    }

    fun importManualConfig(name: String, rawConfig: String, protocol: VpnProtocol) {
        viewModelScope.launch {
            val res = app.discoveryRepository.importManualConfig(name, rawConfig, protocol)
            _uiBanner.value = res.fold(
                onSuccess = { "Конфигурация ${it.name} импортирована и зашифрована" },
                onFailure = { "Некорректная конфигурация: ${it.message}" }
            )
        }
    }

    fun toggleSourceEnabled(source: ConfigSourceEntity) {
        viewModelScope.launch {
            db.sourceDao().upsert(source.copy(enabled = !source.enabled))
        }
    }

    fun deleteCustomSource(source: ConfigSourceEntity) {
        viewModelScope.launch {
            db.sourceDao().deleteCustom(source.id)
            db.serverDao().deleteBySource(source.id)
        }
    }

    fun setUpdateIntervalHours(hours: Int) {
        prefs.setUpdateIntervalHours(hours)
        ServerUpdateWorker.schedule(app, hours)
    }

    fun setAutoReconnect(enabled: Boolean) = prefs.setAutoReconnect(enabled)

    fun setPreferWireGuard(prefer: Boolean) = prefs.setPreferWireGuard(prefer)

    fun clearLogs() {
        viewModelScope.launch { db.logDao().clearAll() }
    }

    fun dismissBanner() {
        _uiBanner.value = null
    }
}
