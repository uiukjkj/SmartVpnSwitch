package com.smartvpnswitch.engine

import android.content.Context
import android.content.Intent
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream

class WireGuardEngine(private val context: Context) {

    private val backend: Backend by lazy { GoBackend(context.applicationContext) }

    private val _tunnelState = MutableStateFlow(Tunnel.State.DOWN)
    val tunnelState: StateFlow<Tunnel.State> = _tunnelState.asStateFlow()

    private val tunnel = object : Tunnel {
        override fun getName(): String = "smart_wg0"
        override fun onStateChange(newState: Tunnel.State) {
            _tunnelState.value = newState
        }
    }

    fun preparePermission(): Intent? = GoBackend.VpnService.prepare(context)

    suspend fun connect(rawConfig: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val parsed = Config.parse(ByteArrayInputStream(rawConfig.toByteArray(Charsets.UTF_8)))
            backend.setState(tunnel, Tunnel.State.UP, parsed)
            Unit
        }
    }

    suspend fun disconnect(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            backend.setState(tunnel, Tunnel.State.DOWN, null)
            Unit
        }
    }

    suspend fun getTrafficStats(): Pair<Long, Long> = withContext(Dispatchers.IO) {
        runCatching {
            val stats = backend.getStatistics(tunnel)
            stats.totalRx() to stats.totalTx()
        }.getOrDefault(0L to 0L)
    }
}
