package com.smartvpnswitch.discovery

import com.smartvpnswitch.data.AppDatabase
import com.smartvpnswitch.data.ConfigSourceEntity
import com.smartvpnswitch.data.ConnectionLogEntity
import com.smartvpnswitch.data.KeystoreCrypto
import com.smartvpnswitch.data.ServerHealthStatus
import com.smartvpnswitch.data.SourceFormat
import com.smartvpnswitch.data.VpnProtocol
import com.smartvpnswitch.data.VpnServerEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

data class DiscoverySummary(
    val sourcesSynced: Int,
    val serversDiscovered: Int,
    val errors: List<String>
)

class ServerDiscoveryRepository(
    private val db: AppDatabase,
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()
) {
    suspend fun ensureDefaultSources() = withContext(Dispatchers.IO) {
        db.sourceDao().insertIgnore(
            ConfigSourceEntity(
                id = AppDatabase.DEFAULT_VPNGATE_SOURCE_ID,
                name = "VPNGate (University of Tsukuba)",
                url = AppDatabase.DEFAULT_VPNGATE_URL,
                format = SourceFormat.VPNGATE_CSV.name,
                enabled = true,
                isBuiltIn = true
            )
        )
    }

    suspend fun addCustomSource(name: String, url: String, format: SourceFormat): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(url.startsWith("https://", ignoreCase = true)) {
                    "Разрешены только HTTPS-источники конфигураций"
                }
                val id = "src_" + sha256Short(url)
                db.sourceDao().upsert(
                    ConfigSourceEntity(
                        id = id,
                        name = name.trim().ifEmpty { url.take(40) },
                        url = url.trim(),
                        format = format.name,
                        enabled = true,
                        isBuiltIn = false
                    )
                )
                Unit
            }
        }

    suspend fun importManualConfig(name: String, rawText: String, protocol: VpnProtocol): Result<VpnServerEntity> =
        withContext(Dispatchers.IO) {
            runCatching {
                val validated = when (protocol) {
                    VpnProtocol.WIREGUARD -> ConfigValidator.validateWireGuard(rawText).getOrThrow()
                    VpnProtocol.OPENVPN -> ConfigValidator.validateAndSanitizeOpenVpn(rawText).getOrThrow()
                }
                val id = "manual_" + sha256Short(validated.sanitizedConfig)
                val entity = VpnServerEntity(
                    id = id,
                    name = name.trim().ifEmpty { "${protocol.name} ${validated.host}" },
                    host = validated.host,
                    port = validated.port,
                    countryCode = "UN",
                    countryName = "Custom",
                    protocol = protocol.name,
                    sourceId = "manual_import",
                    encryptedConfig = KeystoreCrypto.encrypt(validated.sanitizedConfig),
                    healthStatus = ServerHealthStatus.UNKNOWN.name
                )
                db.serverDao().upsert(entity)
                db.logDao().insert(
                    ConnectionLogEntity(
                        level = "INFO",
                        tag = "Discovery",
                        message = "Импортирован конфиг ${entity.name} (${entity.protocol})"
                    )
                )
                entity
            }
        }

    suspend fun syncAllEnabledSources(): DiscoverySummary = withContext(Dispatchers.IO) {
        ensureDefaultSources()
        val sources = db.sourceDao().getEnabled()
        var totalServers = 0
        var syncedCount = 0
        val errors = mutableListOf<String>()

        for (source in sources) {
            try {
                if (!source.url.startsWith("https://", ignoreCase = true)) {
                    throw IllegalArgumentException("Non-HTTPS URL blocked: ${source.url}")
                }
                val request = Request.Builder()
                    .url(source.url)
                    .header("User-Agent", "SmartVpnSwitch/1.0 (Android 14)")
                    .build()

                val body = httpClient.newCall(request).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        throw IllegalStateException("HTTP ${resp.code}")
                    }
                    resp.body?.string() ?: throw IllegalStateException("Empty body")
                }

                val parsed = parseByFormat(source, body)
                if (parsed.isNotEmpty()) {
                    val existingMap = db.serverDao().getAll().associateBy { it.id }
                    val merged = parsed.map { fresh ->
                        val prev = existingMap[fresh.id]
                        if (prev != null) {
                            fresh.copy(
                                pingMs = if (prev.lastCheckedAt > 0) prev.pingMs else fresh.pingMs,
                                speedBps = if (prev.speedBps > 0) prev.speedBps else fresh.speedBps,
                                healthStatus = prev.healthStatus,
                                failureCount = prev.failureCount,
                                successCount = prev.successCount,
                                lastCheckedAt = prev.lastCheckedAt
                            )
                        } else {
                            fresh
                        }
                    }
                    db.serverDao().upsertAll(merged)
                    db.serverDao().deleteMissingForSource(source.id, merged.map { it.id })
                }

                db.sourceDao().upsert(
                    source.copy(
                        lastSyncedAt = System.currentTimeMillis(),
                        lastError = null,
                        serverCount = parsed.size
                    )
                )
                syncedCount++
                totalServers += parsed.size
                db.logDao().insert(
                    ConnectionLogEntity(
                        level = "SUCCESS",
                        tag = "Discovery",
                        message = "Источник ${source.name}: загружено ${parsed.size} валидных конфигов"
                    )
                )
            } catch (e: Exception) {
                val msg = "${source.name}: ${e.message ?: e.javaClass.simpleName}"
                errors.add(msg)
                db.sourceDao().upsert(source.copy(lastError = e.message))
                db.logDao().insert(
                    ConnectionLogEntity(
                        level = "ERROR",
                        tag = "Discovery",
                        message = "Ошибка синхронизации $msg"
                    )
                )
            }
        }
        db.serverDao().pruneBroken(maxFailures = 5)
        db.logDao().trimOld()
        DiscoverySummary(syncedCount, totalServers, errors)
    }

    private fun parseByFormat(source: ConfigSourceEntity, body: String): List<VpnServerEntity> {
        return when (SourceFormat.valueOf(source.format)) {
            SourceFormat.VPNGATE_CSV -> VpnGateParser.parseCsv(body, source.id)
            SourceFormat.RAW_WIREGUARD_CONF -> {
                val validated = ConfigValidator.validateWireGuard(body).getOrThrow()
                listOf(
                    VpnServerEntity(
                        id = "${source.id}_${validated.host}_${validated.port}",
                        name = "${source.name} (${validated.host})",
                        host = validated.host,
                        port = validated.port,
                        countryCode = "UN",
                        countryName = "Custom WG",
                        protocol = VpnProtocol.WIREGUARD.name,
                        sourceId = source.id,
                        encryptedConfig = KeystoreCrypto.encrypt(validated.sanitizedConfig)
                    )
                )
            }
            SourceFormat.RAW_OPENVPN_OVPN -> {
                val validated = ConfigValidator.validateAndSanitizeOpenVpn(body).getOrThrow()
                listOf(
                    VpnServerEntity(
                        id = "${source.id}_${validated.host}_${validated.port}",
                        name = "${source.name} (${validated.host})",
                        host = validated.host,
                        port = validated.port,
                        countryCode = "UN",
                        countryName = "Custom OVPN",
                        protocol = VpnProtocol.OPENVPN.name,
                        sourceId = source.id,
                        encryptedConfig = KeystoreCrypto.encrypt(validated.sanitizedConfig)
                    )
                )
            }
            SourceFormat.JSON_FEED -> parseJsonFeed(source.id, body)
        }
    }

    private fun parseJsonFeed(sourceId: String, jsonText: String): List<VpnServerEntity> {
        val arr = JSONArray(jsonText)
        val out = mutableListOf<VpnServerEntity>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val protoRaw = obj.optString("protocol", "WIREGUARD").uppercase()
            val protocol = if (protoRaw.contains("OPENVPN")) VpnProtocol.OPENVPN else VpnProtocol.WIREGUARD
            val configText = obj.optString("config")
            val name = obj.optString("name", "Server #${i + 1}")
            val countryCode = obj.optString("countryCode", "UN").take(2).uppercase()
            val countryName = obj.optString("countryName", "Unknown")
            val validated = when (protocol) {
                VpnProtocol.WIREGUARD -> ConfigValidator.validateWireGuard(configText).getOrNull()
                VpnProtocol.OPENVPN -> ConfigValidator.validateAndSanitizeOpenVpn(configText).getOrNull()
            } ?: continue

            out.add(
                VpnServerEntity(
                    id = "${sourceId}_${validated.host}_${validated.port}_$i",
                    name = name,
                    host = validated.host,
                    port = validated.port,
                    countryCode = countryCode,
                    countryName = countryName,
                    protocol = protocol.name,
                    sourceId = sourceId,
                    encryptedConfig = KeystoreCrypto.encrypt(validated.sanitizedConfig)
                )
            )
        }
        return out
    }

    private fun sha256Short(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return digest.take(8).joinToString("") { "%02x".format(it) }
    }
}
