package com.smartvpnswitch.buttons

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.smartvpnswitch.controller.SmartVpnForegroundService

/**
 * Optional fallback listener for raw KeyEvents (disabled by default).
 * Note: On 8849/Unihertz Android 14 firmware, Shortcut settings proxy activities
 * (Func1ToggleProxyActivity / Func2NextServerProxyActivity) are recommended instead,
 * because AccessibilityService does not receive keys when the screen is off and
 * OEM ShortcutKey may consume keys earlier.
 */
class OptionalButtonAccessibilityService : AccessibilityService() {

    private var func1KeyCode = KeyEvent.KEYCODE_F1
    private var func2KeyCode = KeyEvent.KEYCODE_F2
    private var func2LongHandled = false

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == func1KeyCode && event.action == KeyEvent.ACTION_UP) {
            if ((event.eventTime - event.downTime) < 500L) {
                SmartVpnForegroundService.dispatchAction(
                    applicationContext,
                    SmartVpnForegroundService.ACTION_TOGGLE
                )
                return true
            }
        }

        if (event.keyCode == func2KeyCode) {
            when (event.action) {
                KeyEvent.ACTION_DOWN -> {
                    if (event.repeatCount == 0) func2LongHandled = false
                    if (!func2LongHandled && (event.isLongPress || (event.eventTime - event.downTime) >= 550L)) {
                        func2LongHandled = true
                        SmartVpnForegroundService.dispatchAction(
                            applicationContext,
                            SmartVpnForegroundService.ACTION_NEXT_SERVER
                        )
                        return true
                    }
                }
                KeyEvent.ACTION_UP -> {
                    if (func2LongHandled) return true
                }
            }
        }
        return super.onKeyEvent(event)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit
}
