package com.smartvpnswitch.buttons

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.smartvpnswitch.SmartVpnApplication
import com.smartvpnswitch.controller.SmartVpnForegroundService
import com.smartvpnswitch.ui.MainActivity

/**
 * Invisible launcher trampoline assigned in 8849 Shark 3:
 * Settings -> Shortcut settings -> Func1 -> Single press.
 */
class Func1ToggleProxyActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as SmartVpnApplication
        val prepareIntent = app.vpnController.prepareVpnPermissionIntent()

        if (prepareIntent != null) {
            // First-time VPN consent required by Android OS; route user to MainActivity once
            Toast.makeText(
                applicationContext,
                "Требуется однократное разрешение VPN в Android",
                Toast.LENGTH_SHORT
            ).show()
            startActivity(
                Intent(this, MainActivity::class.java).apply {
                    putExtra(MainActivity.EXTRA_REQUEST_VPN_PERMISSION, true)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        } else {
            SmartVpnForegroundService.dispatchAction(
                applicationContext,
                SmartVpnForegroundService.ACTION_TOGGLE
            )
            Toast.makeText(applicationContext, "Smart VPN: переключение...", Toast.LENGTH_SHORT).show()
        }
        finishAndRemoveTask()
    }
}
