package com.smartvpnswitch.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun ButtonsScreen() {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Кнопки 8849 Shark 3 (Func1 / Func2)",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Рекомендуемый способ (без Root и без AccessibilityService)", fontWeight = FontWeight.SemiBold)
                Text(
                    "На Unihertz / 8849 системная служба Shortcut settings перехватывает нажатия Func1/Func2 до сторонних сервисов. Поэтому приложение предоставляет две невидимые точки запуска:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text("1. Откройте Настройки -> Shortcut settings", style = MaterialTheme.typography.bodySmall)
                Text("2. Func1 -> Короткое нажатие -> выберите 'Smart VPN: Вкл/Выкл (FUNC1)'", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                Text("3. Func2 -> Долгое нажатие -> выберите 'Smart VPN: След. сервер (FUNC2)'", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                Spacer(modifier = Modifier.height(6.dp))
                Button(
                    onClick = {
                        context.startActivity(Intent(Settings.ACTION_SETTINGS))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Открыть Настройки телефона")
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Важно для MediaTek DuraSpeed / Android 14", fontWeight = FontWeight.SemiBold)
                Text(
                    "Чтобы туннель и быстрое переключение не убивались в фоне, добавьте Smart VPN Switch (и OpenVPN for Android, если используется) в исключения батареи (Не ограничивать) и отключите ограничение в DuraSpeed.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(
                    onClick = {
                        context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Настройки оптимизации батареи")
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Опциональный резерв: AccessibilityService", fontWeight = FontWeight.SemiBold)
                Text(
                    "Нужен только если вы тестируете прямой перехват KeyEvent (не работает при выключенном экране; для sideload APK сначала нажмите 'Разрешить ограниченные настройки' в О приложении).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(
                    onClick = {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Открыть Спец. возможности")
                }
            }
        }
    }
}
