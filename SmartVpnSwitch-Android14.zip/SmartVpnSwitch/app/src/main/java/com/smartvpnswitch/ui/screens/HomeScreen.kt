package com.smartvpnswitch.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smartvpnswitch.data.ServerHealthStatus
import com.smartvpnswitch.engine.VpnStatus
import com.smartvpnswitch.ui.MainViewModel

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onRequestToggleVpn: () -> Unit
) {
    val runtime by viewModel.runtimeState.collectAsState()
    val servers by viewModel.servers.collectAsState()
    val isSyncing by viewModel.isSyncing.collectAsState()

    val availableCount = servers.count { it.healthStatus != ServerHealthStatus.UNHEALTHY.name }
    val isConnected = runtime.status == VpnStatus.CONNECTED
    val isBusy = runtime.status == VpnStatus.CONNECTING || runtime.status == VpnStatus.VERIFYING

    val statusText = when (runtime.status) {
        VpnStatus.CONNECTED -> "ПОДКЛЮЧЕНО"
        VpnStatus.CONNECTING -> "ПОДКЛЮЧЕНИЕ..."
        VpnStatus.VERIFYING -> "ПРОВЕРКА ТУННЕЛЯ..."
        VpnStatus.DISCONNECTED -> "ОТКЛЮЧЕНО"
        VpnStatus.ERROR -> "ОШИБКА"
    }

    val statusColor = when (runtime.status) {
        VpnStatus.CONNECTED -> Color(0xFF10B981)
        VpnStatus.CONNECTING, VpnStatus.VERIFYING -> Color(0xFFF59E0B)
        VpnStatus.ERROR -> Color(0xFFEF4444)
        VpnStatus.DISCONNECTED -> Color(0xFF9CA3AF)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "SMART VPN SWITCH",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = statusText,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.ExtraBold,
            color = statusColor
        )
        Text(
            text = runtime.statusDetail,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Большая кнопка подключения VPN
        Button(
            onClick = onRequestToggleVpn,
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isConnected) Color(0xFF10B981) else MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.size(164.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (isBusy) {
                    CircularProgressIndicator(
                        color = Color.Black,
                        modifier = Modifier.size(44.dp),
                        strokeWidth = 4.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.PowerSettingsNew,
                        contentDescription = null,
                        modifier = Modifier.size(52.dp)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isConnected || isBusy) "ОТКЛЮЧИТЬ" else "ПОДКЛЮЧИТЬ",
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = { viewModel.switchToNextServer() },
                modifier = Modifier.weight(1f),
                enabled = availableCount > 0
            ) {
                Icon(Icons.Default.SwapHoriz, contentDescription = null)
                Spacer(Modifier.size(6.dp))
                Text("След. сервер")
            }
            OutlinedButton(
                onClick = { viewModel.syncAndProbeServers() },
                modifier = Modifier.weight(1f),
                enabled = !isSyncing
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(Modifier.size(6.dp))
                Text(if (isSyncing) "Поиск..." else "Обновить")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        val active = runtime.activeServer
        val speedText = if (active != null && active.speedBps > 0) {
            String.format("%.2f Мбит/с", active.speedBps / 1_000_000.0)
        } else {
            "—"
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricRow("Публичный IP", runtime.publicIp)
                MetricRow("Страна сервера", active?.let { "${it.countryName} (${it.countryCode})" } ?: "—")
                MetricRow("Название сервера", active?.name ?: "—")
                MetricRow("Протокол", active?.protocol ?: "—")
                MetricRow("Ping", active?.takeIf { it.pingMs > 0 }?.let { "${it.pingMs} мс" } ?: "—")
                MetricRow("Скорость", speedText)
                MetricRow("Доступно серверов", "$availableCount / ${servers.size}")
                if (runtime.rxBytes > 0 || runtime.txBytes > 0) {
                    MetricRow("Трафик (RX / TX)", "${runtime.rxBytes / 1024} КБ / ${runtime.txBytes / 1024} КБ")
                }
            }
        }
    }
}

@Composable
private fun MetricRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
    }
}
