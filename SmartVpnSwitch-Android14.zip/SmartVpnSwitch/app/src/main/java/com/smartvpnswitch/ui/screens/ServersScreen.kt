package com.smartvpnswitch.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smartvpnswitch.data.ServerHealthStatus
import com.smartvpnswitch.data.VpnServerEntity
import com.smartvpnswitch.ui.MainViewModel

@Composable
fun ServersScreen(
    viewModel: MainViewModel,
    onConnectServer: (VpnServerEntity) -> Unit
) {
    val servers by viewModel.servers.collectAsState()
    val runtime by viewModel.runtimeState.collectAsState()
    val openVpnInstalled by viewModel.openVpnAppInstalled.collectAsState()
    var query by remember { mutableStateOf("") }

    val filtered = remember(servers, query) {
        if (query.isBlank()) servers
        else servers.filter {
            it.name.contains(query, true) ||
                it.countryName.contains(query, true) ||
                it.protocol.contains(query, true)
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Серверы (${filtered.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            IconButton(onClick = { viewModel.syncAndProbeServers() }) {
                Icon(Icons.Default.Refresh, contentDescription = "Обновить")
            }
        }

        if (!openVpnInstalled) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF3B2A12))
            ) {
                Text(
                    text = "OpenVPN for Android (de.blinkt.openvpn) не установлен. Для подключения к OpenVPN-серверам (вкл. VPNGate) установите официальный OpenVPN for Android; WireGuard работает встроенно.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(12.dp),
                    color = Color(0xFFFCD34D)
                )
            }
        }

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Поиск по стране, имени или протоколу") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { srv ->
                val isActive = runtime.activeServer?.id == srv.id
                val healthColor = when (srv.healthStatus) {
                    ServerHealthStatus.VERIFIED.name -> Color(0xFF10B981)
                    ServerHealthStatus.REACHABLE.name -> Color(0xFFF59E0B)
                    ServerHealthStatus.UNHEALTHY.name -> Color(0xFFEF4444)
                    else -> Color(0xFF9CA3AF)
                }
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onConnectServer(srv) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isActive) Color(0xFF162B23) else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(srv.name, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            Text(srv.protocol, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${srv.countryName} · ${srv.host}:${srv.port}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${srv.healthStatus} · ${if (srv.pingMs > 0) "${srv.pingMs}ms" else "—"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = healthColor
                            )
                        }
                    }
                }
            }
        }
    }
}
