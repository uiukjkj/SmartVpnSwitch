package com.smartvpnswitch.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class UserSettings(
    val updateIntervalHours: Int = 12, // 0 = manual only, 6, 12, 24
    val autoReconnect: Boolean = true,
    val preferWireGuard: Boolean = true,
    val lastServerId: String? = null
)

class AppPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("smart_vpn_prefs", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<UserSettings> = _settings.asStateFlow()

    private fun load(): UserSettings = UserSettings(
        updateIntervalHours = prefs.getInt(KEY_UPDATE_INTERVAL, 12),
        autoReconnect = prefs.getBoolean(KEY_AUTO_RECONNECT, true),
        preferWireGuard = prefs.getBoolean(KEY_PREFER_WG, true),
        lastServerId = prefs.getString(KEY_LAST_SERVER, null)
    )

    fun setUpdateIntervalHours(hours: Int) {
        prefs.edit().putInt(KEY_UPDATE_INTERVAL, hours).apply()
        _settings.value = load()
    }

    fun setAutoReconnect(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_RECONNECT, enabled).apply()
        _settings.value = load()
    }

    fun setPreferWireGuard(prefer: Boolean) {
        prefs.edit().putBoolean(KEY_PREFER_WG, prefer).apply()
        _settings.value = load()
    }

    fun setLastServerId(serverId: String?) {
        prefs.edit().putString(KEY_LAST_SERVER, serverId).apply()
        _settings.value = load()
    }

    companion object {
        private const val KEY_UPDATE_INTERVAL = "update_interval_hours"
        private const val KEY_AUTO_RECONNECT = "auto_reconnect"
        private const val KEY_PREFER_WG = "prefer_wireguard"
        private const val KEY_LAST_SERVER = "last_server_id"
    }
}
