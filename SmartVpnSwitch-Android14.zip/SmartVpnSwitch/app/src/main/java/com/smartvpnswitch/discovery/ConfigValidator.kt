package com.smartvpnswitch.discovery

import com.wireguard.config.Config
import java.io.ByteArrayInputStream

data class ValidatedEndpoint(
    val host: String,
    val port: Int,
    val sanitizedConfig: String
)

object ConfigValidator {
    private const val MAX_CONFIG_BYTES = 128 * 1024

    // Dangerous OpenVPN directives that execute external scripts/plugins or arbitrary paths
    private val forbiddenOvpnDirectives = setOf(
        "script-security",
        "up",
        "down",
        "route-up",
        "route-pre-down",
        "ipchange",
        "learn-address",
        "client-connect",
        "client-disconnect",
        "plugin",
        "tls-verify",
        "auth-user-pass-verify",
        "management"
    )

    fun validateWireGuard(rawConf: String): Result<ValidatedEndpoint> = runCatching {
        require(rawConf.isNotBlank() && rawConf.toByteArray().size <= MAX_CONFIG_BYTES) {
            "WireGuard config is empty or exceeds 128 KB"
        }
        val parsed = Config.parse(ByteArrayInputStream(rawConf.toByteArray(Charsets.UTF_8)))
        val peer = parsed.peers.firstOrNull()
            ?: error("WireGuard config contains no [Peer] section")
        val endpoint = peer.endpoint.orElse(null)
            ?: error("WireGuard [Peer] has no Endpoint")

        ValidatedEndpoint(
            host = endpoint.host,
            port = endpoint.port,
            sanitizedConfig = parsed.toWgUserspaceString().let { rawConf.trim() }
        )
    }

    fun validateAndSanitizeOpenVpn(rawOvpn: String, appendVpnGateAuth: Boolean = false): Result<ValidatedEndpoint> = runCatching {
        require(rawOvpn.isNotBlank() && rawOvpn.toByteArray().size <= MAX_CONFIG_BYTES) {
            "OpenVPN config is empty or exceeds 128 KB"
        }
        // Reject obvious binary/executable payloads
        require(!rawOvpn.contains('\u0000')) { "Invalid binary bytes in OpenVPN config" }

        val cleanLines = mutableListOf<String>()
        var remoteHost: String? = null
        var remotePort = 1194
        var hasClientDirective = false
        var hasAuthUserPass = false

        for (rawLine in rawOvpn.lineSequence()) {
            val line = rawLine.trim()
            if (line.isEmpty() || line.startsWith("#") || line.startsWith(";")) {
                continue
            }
            val token = line.split(Regex("\\s+"), limit = 2).first().lowercase()
            require(token !in forbiddenOvpnDirectives) {
                "Blocked unsafe OpenVPN directive: $token"
            }
            if (token == "client") hasClientDirective = true
            if (token == "auth-user-pass") hasAuthUserPass = true
            if (token == "remote" && remoteHost == null) {
                val parts = line.split(Regex("\\s+"))
                if (parts.size >= 2) {
                    remoteHost = parts[1]
                    remotePort = parts.getOrNull(2)?.toIntOrNull() ?: 1194
                }
            }
            cleanLines.add(rawLine.trimEnd())
        }

        val host = remoteHost ?: error("OpenVPN config missing 'remote' host")
        require(hasClientDirective || cleanLines.any { it.trim().startsWith("proto ") }) {
            "Missing OpenVPN client/proto directives"
        }

        if (appendVpnGateAuth && !hasAuthUserPass && !rawOvpn.contains("<auth-user-pass>")) {
            cleanLines.add("")
            cleanLines.add("<auth-user-pass>")
            cleanLines.add("vpn")
            cleanLines.add("vpn")
            cleanLines.add("</auth-user-pass>")
        }

        ValidatedEndpoint(
            host = host,
            port = remotePort,
            sanitizedConfig = cleanLines.joinToString("\n")
        )
    }
}
