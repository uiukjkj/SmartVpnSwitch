package com.smartvpnswitch.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smartvpnswitch.data.SourceFormat
import com.smartvpnswitch.data.VpnProtocol
import com.smartvpnswitch.ui.MainViewModel

@Composable
fun SourcesScreen(viewModel: MainViewModel) {
    val sources by viewModel.sources.collectAsState()

    var newSourceName by remember { mutableStateOf("") }
    var newSourceUrl by remember { mutableStateOf("") }
    var selectedFormat by remember { mutableStateOf(SourceFormat.RAW_WIREGUARD_CONF) }

    var manualName by remember { mutableStateOf("") }
    var manualConfig by remember { mutableStateOf("") }
    var manualProtocol by remember { mutableStateOf(VpnProtocol.WIREGUARD) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Источники конфигураций", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "Разрешены только HTTPS-источники. Все загружаемые файлы проходят валидацию синтаксиса и очистку от опасных директив.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        items(sources, key = { it.id }) { src ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(src.name, fontWeight = FontWeight.SemiBold)
                        Text(src.url, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "Формат: ${src.format} · Серверов: ${src.serverCount}",
                            style = MaterialTheme.typography.labelSmall
                        )
                        src.lastError?.let {
                            Text("Ошибка: $it", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                    Switch(checked = src.enabled, onCheckedChange = { viewModel.toggleSourceEnabled(src) })
                    if (!src.isBuiltIn) {
                        IconButton(onClick = { viewModel.deleteCustomSource(src) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Удалить")
                        }
                    }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Добавить HTTPS-источник", fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = newSourceName,
                        onValueChange = { newSourceName = it },
                        label = { Text("Название") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = newSourceUrl,
                        onValueChange = { newSourceUrl = it },
                        label = { Text("HTTPS URL") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            SourceFormat.RAW_WIREGUARD_CONF to "WG .conf",
                            SourceFormat.RAW_OPENVPN_OVPN to "OVPN",
                            SourceFormat.JSON_FEED to "JSON"
                        ).forEach { (fmt, label) ->
                            FilterChip(
                                selected = selectedFormat == fmt,
                                onClick = { selectedFormat = fmt },
                                label = { Text(label) }
                            )
                        }
                    }
                    Button(
                        onClick = {
                            viewModel.addSource(newSourceName, newSourceUrl, selectedFormat)
                            newSourceName = ""
                            newSourceUrl = ""
                        },
                        enabled = newSourceUrl.isNotBlank()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Text(" Добавить источник")
                    }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Импорт конфигурации вручную (.conf / .ovpn)", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = manualProtocol == VpnProtocol.WIREGUARD,
                            onClick = { manualProtocol = VpnProtocol.WIREGUARD },
                            label = { Text("WireGuard") }
                        )
                        FilterChip(
                            selected = manualProtocol == VpnProtocol.OPENVPN,
                            onClick = { manualProtocol = VpnProtocol.OPENVPN },
                            label = { Text("OpenVPN") }
                        )
                    }
                    OutlinedTextField(
                        value = manualName,
                        onValueChange = { manualName = it },
                        label = { Text("Название сервера") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = manualConfig,
                        onValueChange = { manualConfig = it },
                        label = { Text("Вставьте текст конфигурации") },
                        modifier = Modifier.fillMaxWidth().height(120.dp)
                    )
                    OutlinedButton(
                        onClick = {
                            viewModel.importManualConfig(manualName, manualConfig, manualProtocol)
                            manualName = ""
                            manualConfig = ""
                        },
                        enabled = manualConfig.isNotBlank()
                    ) {
                        Text("Проверить и сохранить в Keystore")
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
