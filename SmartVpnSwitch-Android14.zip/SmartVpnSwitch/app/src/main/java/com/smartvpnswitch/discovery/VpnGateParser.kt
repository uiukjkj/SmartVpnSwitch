package com.smartvpnswitch.discovery

import android.util.Base64
import com.smartvpnswitch.data.KeystoreCrypto
import com.smartvpnswitch.data.ServerHealthStatus
import com.smartvpnswitch.data.VpnProtocol
import com.smartvpnswitch.data.VpnServerEntity

object VpnGateParser {

    /**
     * Parses official University of Tsukuba VPNGate CSV feed:
     * #HostName,IP,Score,Ping,Speed,CountryLong,CountryShort,NumVpnSessions,Uptime,TotalUsers,TotalTraffic,LogType,Operator,Message,OpenVPN_ConfigData_Base64
     */
    fun parseCsv(csvBody: String, sourceId: String, maxEntries: Int = 60): List<VpnServerEntity> {
        val result = mutableListOf<VpnServerEntity>()
        val lines = csvBody.lineSequence()
        for (line in lines) {
            if (line.isBlank() || line.startsWith("*") || line.startsWith("#")) continue
            val cols = line.split(',')
            if (cols.size < 15) continue

            val hostName = cols[0].trim()
            val ip = cols[1].trim()
            val ping = cols[3].trim().toIntOrNull() ?: -1
            val speed = cols[4].trim().toLongOrNull() ?: 0L
            val countryLong = cols[5].trim().ifEmpty { "Unknown" }
            val countryShort = cols[6].trim().ifEmpty { "UN" }
            val uptime = cols[8].trim().toLongOrNull() ?: 0L
            val configB64 = cols[14].trim()
            if (configB64.isEmpty()) continue

            val decodedOvpn = runCatching {
                String(Base64.decode(configB64, Base64.DEFAULT), Charsets.UTF_8)
            }.getOrNull() ?: continue

            val validated = ConfigValidator.validateAndSanitizeOpenVpn(
                rawOvpn = decodedOvpn,
                appendVpnGateAuth = true
            ).getOrNull() ?: continue

            val encrypted = runCatching {
                KeystoreCrypto.encrypt(validated.sanitizedConfig)
            }.getOrNull() ?: continue

            val serverId = "vpngate_${hostName}_${validated.host}_${validated.port}"
            result.add(
                VpnServerEntity(
                    id = serverId,
                    name = "VPNGate $hostName ($countryShort)",
                    host = validated.host.ifBlank { ip },
                    port = validated.port,
                    countryCode = countryShort,
                    countryName = countryLong,
                    protocol = VpnProtocol.OPENVPN.name,
                    sourceId = sourceId,
                    encryptedConfig = encrypted,
                    pingMs = ping,
                    speedBps = speed,
                    uptimeMs = uptime,
                    healthStatus = ServerHealthStatus.UNKNOWN.name
                )
            )
            if (result.size >= maxEntries) break
        }
        return result
    }
}
