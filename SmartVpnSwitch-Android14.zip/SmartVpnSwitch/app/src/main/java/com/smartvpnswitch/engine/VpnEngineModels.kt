package com.smartvpnswitch.engine

import com.smartvpnswitch.data.VpnServerEntity

enum class VpnStatus {
    DISCONNECTED,
    CONNECTING,
    VERIFYING,
    CONNECTED,
    ERROR
}

data class VpnRuntimeState(
    val status: VpnStatus = VpnStatus.DISCONNECTED,
    val activeServer: VpnServerEntity? = null,
    val publicIp: String = "—",
    val rxBytes: Long = 0L,
    val txBytes: Long = 0L,
    val statusDetail: String = "Отключено"
)
