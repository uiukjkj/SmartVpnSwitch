package com.smartvpnswitch

import android.app.Application
import com.smartvpnswitch.checker.PublicIpService
import com.smartvpnswitch.checker.ServerProbe
import com.smartvpnswitch.controller.SmartVpnController
import com.smartvpnswitch.controller.SmartVpnNotificationHelper
import com.smartvpnswitch.data.AppDatabase
import com.smartvpnswitch.data.AppPreferences
import com.smartvpnswitch.discovery.ServerDiscoveryRepository
import com.smartvpnswitch.engine.OpenVpnAidlEngine
import com.smartvpnswitch.engine.WireGuardEngine
import com.smartvpnswitch.worker.ServerUpdateWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class SmartVpnApplication : Application() {

    lateinit var database: AppDatabase
        private set
    lateinit var preferences: AppPreferences
        private set
    lateinit var discoveryRepository: ServerDiscoveryRepository
        private set
    lateinit var serverProbe: ServerProbe
        private set
    lateinit var publicIpService: PublicIpService
        private set
    lateinit var vpnController: SmartVpnController
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        SmartVpnNotificationHelper.ensureChannel(this)

        database = AppDatabase.getInstance(this)
        preferences = AppPreferences(this)
        discoveryRepository = ServerDiscoveryRepository(database)
        serverProbe = ServerProbe(database)
        publicIpService = PublicIpService()

        val wgEngine = WireGuardEngine(this)
        val ovpnEngine = OpenVpnAidlEngine(this)

        vpnController = SmartVpnController(
            context = this,
            db = database,
            prefs = preferences,
            discoveryRepo = discoveryRepository,
            serverProbe = serverProbe,
            ipService = publicIpService,
            wireGuardEngine = wgEngine,
            openVpnEngine = ovpnEngine
        )

        appScope.launch {
            discoveryRepository.ensureDefaultSources()
            vpnController.refreshPublicIpOutsideOrInside()
        }

        ServerUpdateWorker.schedule(this, preferences.settings.value.updateIntervalHours)
    }
}
