package com.smartvpnswitch.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.smartvpnswitch.ui.screens.ButtonsScreen
import com.smartvpnswitch.ui.screens.HomeScreen
import com.smartvpnswitch.ui.screens.ServersScreen
import com.smartvpnswitch.ui.screens.SettingsLogScreen
import com.smartvpnswitch.ui.screens.SourcesScreen

class MainActivity : ComponentActivity() {

    companion object {
        const val EXTRA_REQUEST_VPN_PERMISSION = "extra_request_vpn_perm"
    }

    private val viewModel: MainViewModel by viewModels()
    private var pendingAutoConnectAfterPerm = false

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && pendingAutoConnectAfterPerm) {
            pendingAutoConnectAfterPerm = false
            viewModel.toggleVpn()
        } else {
            pendingAutoConnectAfterPerm = false
        }
    }

    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermissionIfNeeded()

        if (intent?.getBooleanExtra(EXTRA_REQUEST_VPN_PERMISSION, false) == true) {
            requestVpnPermissionAndConnect()
        }

        setContent {
            SmartVpnTheme {
                var selectedTab by remember { mutableIntStateOf(0) }
                val snackbarHostState = remember { SnackbarHostState() }
                val banner by viewModel.uiBanner.collectAsState()

                LaunchedEffect(banner) {
                    banner?.let {
                        snackbarHostState.showSnackbar(it)
                        viewModel.dismissBanner()
                    }
                }

                Scaffold(
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                icon = { Icon(Icons.Default.PowerSettingsNew, contentDescription = null) },
                                label = { Text("VPN") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                icon = { Icon(Icons.Default.FormatListBulleted, contentDescription = null) },
                                label = { Text("Серверы") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 2,
                                onClick = { selectedTab = 2 },
                                icon = { Icon(Icons.Default.Dns, contentDescription = null) },
                                label = { Text("Источники") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 3,
                                onClick = { selectedTab = 3 },
                                icon = { Icon(Icons.Default.Gamepad, contentDescription = null) },
                                label = { Text("Кнопки") }
                            )
                            NavigationBarItem(
                                selected = selectedTab == 4,
                                onClick = { selectedTab = 4 },
                                icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                                label = { Text("Журнал") }
                            )
                        }
                    }
                ) { padding ->
                    Box(modifier = Modifier.padding(padding)) {
                        when (selectedTab) {
                            0 -> HomeScreen(
                                viewModel = viewModel,
                                onRequestToggleVpn = { requestVpnPermissionAndConnect() }
                            )
                            1 -> ServersScreen(
                                viewModel = viewModel,
                                onConnectServer = { srv ->
                                    val perm = viewModel.prepareVpnPermission()
                                    if (perm != null) {
                                        vpnPermissionLauncher.launch(perm)
                                    } else {
                                        viewModel.connectServer(srv)
                                    }
                                }
                            )
                            2 -> SourcesScreen(viewModel = viewModel)
                            3 -> ButtonsScreen()
                            4 -> SettingsLogScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshCapabilities()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(EXTRA_REQUEST_VPN_PERMISSION, false)) {
            requestVpnPermissionAndConnect()
        }
    }

    private fun requestVpnPermissionAndConnect() {
        val intent = viewModel.prepareVpnPermission()
        if (intent != null) {
            pendingAutoConnectAfterPerm = true
            vpnPermissionLauncher.launch(intent)
        } else {
            viewModel.toggleVpn()
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
