package com.smartvpnswitch.controller

import com.smartvpnswitch.data.ServerHealthStatus
import com.smartvpnswitch.data.VpnProtocol
import com.smartvpnswitch.data.VpnServerEntity

object ServerSelector {

    fun score(server: VpnServerEntity, preferWireGuard: Boolean): Double {
        var points = 0.0
        when (server.healthStatus) {
            ServerHealthStatus.VERIFIED.name -> points += 500.0
            ServerHealthStatus.REACHABLE.name -> points += 250.0
            ServerHealthStatus.UNKNOWN.name -> points += 100.0
            ServerHealthStatus.UNHEALTHY.name -> points -= 1000.0
        }
        if (preferWireGuard && server.protocol == VpnProtocol.WIREGUARD.name) {
            points += 120.0
        }
        if (server.pingMs > 0) {
            points += (400.0 - server.pingMs.coerceAtMost(400))
        }
        if (server.speedBps > 0) {
            points += (server.speedBps / 1_000_000.0).coerceAtMost(150.0)
        }
        points += (server.successCount * 35.0).coerceAtMost(200.0)
        points -= (server.failureCount * 180.0)
        return points
    }

    fun pickBest(
        servers: List<VpnServerEntity>,
        preferWireGuard: Boolean,
        openVpnAvailable: Boolean,
        excludeIds: Set<String> = emptySet()
    ): VpnServerEntity? {
        return servers
            .asSequence()
            .filter { it.id !in excludeIds }
            .filter { it.protocol == VpnProtocol.WIREGUARD.name || openVpnAvailable }
            .filter { it.healthStatus != ServerHealthStatus.UNHEALTHY.name }
            .maxByOrNull { score(it, preferWireGuard) }
            ?: servers
                .asSequence()
                .filter { it.id !in excludeIds }
                .filter { it.protocol == VpnProtocol.WIREGUARD.name || openVpnAvailable }
                .maxByOrNull { score(it, preferWireGuard) }
    }
}
