package com.smartvpnswitch.engine

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import de.blinkt.openvpn.api.IOpenVPNAPIService
import de.blinkt.openvpn.api.IOpenVPNStatusCallback
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

data class OpenVpnStateSnapshot(
    val level: String = "LEVEL_NOTCONNECTED",
    val state: String = "NOPROCESS",
    val message: String = ""
)

class OpenVpnAidlEngine(private val context: Context) {

    companion object {
        const val OPENVPN_PACKAGE = "de.blinkt.openvpn"
        private const val SERVICE_ACTION = "de.blinkt.openvpn.api.IOpenVPNAPIService"
    }

    private var apiService: IOpenVPNAPIService? = null
    private var pendingConnectDeferred: CompletableDeferred<IOpenVPNAPIService?>? = null

    private val _state = MutableStateFlow(OpenVpnStateSnapshot())
    val state: StateFlow<OpenVpnStateSnapshot> = _state.asStateFlow()

    private val statusCallback = object : IOpenVPNStatusCallback.Stub() {
        override fun newStatus(uuid: String?, state: String?, message: String?, level: String?) {
            _state.value = OpenVpnStateSnapshot(
                level = level ?: "LEVEL_NOTCONNECTED",
                state = state ?: "UNKNOWN",
                message = message ?: ""
            )
        }
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val api = IOpenVPNAPIService.Stub.asInterface(service)
            apiService = api
            runCatching { api?.registerStatusCallback(statusCallback) }
            pendingConnectDeferred?.complete(api)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            apiService = null
            _state.value = OpenVpnStateSnapshot()
        }
    }

    fun isOpenVpnInstalled(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(
                    OPENVPN_PACKAGE,
                    PackageManager.PackageInfoFlags.of(0)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(OPENVPN_PACKAGE, 0)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun ensureBound(): IOpenVPNAPIService? = withContext(Dispatchers.Main) {
        apiService?.let { return@withContext it }
        if (!isOpenVpnInstalled()) return@withContext null

        val deferred = CompletableDeferred<IOpenVPNAPIService?>()
        pendingConnectDeferred = deferred
        val intent = Intent(SERVICE_ACTION).apply {
            setPackage(OPENVPN_PACKAGE)
        }
        val ok = context.bindService(intent, connection, Context.BIND_AUTO_CREATE)
        if (!ok) {
            pendingConnectDeferred = null
            return@withContext null
        }
        withTimeoutOrNull(4000L) { deferred.await() }
    }

    suspend fun prepareApiPermission(): Intent? {
        val api = ensureBound() ?: return null
        return runCatching {
            api.prepare(context.packageName) ?: api.prepareVPNService()
        }.getOrNull()
    }

    suspend fun connect(inlineOvpnConfig: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val api = ensureBound()
                ?: error("OpenVPN for Android ($OPENVPN_PACKAGE) не установлен или не отвечает")
            val permIntent = api.prepare(context.packageName) ?: api.prepareVPNService()
            if (permIntent != null) {
                error("Требуется подтверждение разрешений OpenVPN for Android")
            }
            api.startVPN(inlineOvpnConfig)
        }
    }

    suspend fun disconnect(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            apiService?.disconnect()
            Unit
        }
    }

    fun unbind() {
        runCatching { apiService?.unregisterStatusCallback(statusCallback) }
        runCatching { context.unbindService(connection) }
        apiService = null
    }
}
