package com.smartvpnswitch.controller

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.smartvpnswitch.SmartVpnApplication

class SmartVpnForegroundService : Service() {

    companion object {
        const val ACTION_TOGGLE = "com.smartvpnswitch.action.TOGGLE"
        const val ACTION_NEXT_SERVER = "com.smartvpnswitch.action.NEXT_SERVER"
        const val ACTION_DISCONNECT = "com.smartvpnswitch.action.DISCONNECT"

        fun dispatchAction(context: Context, action: String) {
            val intent = Intent(context, SmartVpnForegroundService::class.java).setAction(action)
            context.startForegroundService(intent)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = SmartVpnNotificationHelper.buildNotification(
            this,
            "Smart VPN Switch",
            "Обработка команды VPN..."
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                SmartVpnNotificationHelper.NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(SmartVpnNotificationHelper.NOTIFICATION_ID, notification)
        }

        val controller = (application as SmartVpnApplication).vpnController
        when (intent?.action) {
            ACTION_TOGGLE -> controller.toggleVpn()
            ACTION_NEXT_SERVER -> controller.switchToNextServer()
            ACTION_DISCONNECT -> {
                controller.disconnect()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }
}
