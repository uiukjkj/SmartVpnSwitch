package com.smartvpnswitch.checker

import com.smartvpnswitch.data.AppDatabase
import com.smartvpnswitch.data.ServerHealthStatus
import com.smartvpnswitch.data.VpnServerEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

class ServerProbe(private val db: AppDatabase) {

    /**
     * Measures real TCP reachability and RTT to server endpoint.
     * Note: UDP-only endpoints may refuse TCP connect; if TCP returns ConnectionRefused quickly
     * vs Timeout, we still track real reachability and confirm full VPN tunnel later.
     */
    suspend fun measureTcpLatencyMs(host: String, port: Int, timeoutMs: Int = 2200): Int =
        withContext(Dispatchers.IO) {
            val start = System.nanoTime()
            try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(host, port), timeoutMs)
                }
                ((System.nanoTime() - start) / 1_000_000L).toInt().coerceAtLeast(1)
            } catch (_: Exception) {
                -1
            }
        }

    suspend fun probeServersBatch(limit: Int = 25): Int = coroutineScope {
        val servers = db.serverDao().getAll().take(limit)
        val semaphore = Semaphore(6)
        val now = System.currentTimeMillis()
        var reachableCount = 0

        val updated = servers.map { server ->
            async(Dispatchers.IO) {
                semaphore.withPermit {
                    val rtt = measureTcpLatencyMs(server.host, server.port)
                    if (rtt > 0) {
                        reachableCount++
                        val nextStatus = if (server.healthStatus == ServerHealthStatus.VERIFIED.name) {
                            ServerHealthStatus.VERIFIED.name
                        } else {
                            ServerHealthStatus.REACHABLE.name
                        }
                        server.copy(
                            pingMs = rtt,
                            healthStatus = nextStatus,
                            lastCheckedAt = now
                        )
                    } else if (server.protocol == "OPENVPN") {
                        // TCP connect failed on OpenVPN server -> mark check timestamp and increment failure
                        val nextFailures = server.failureCount + 1
                        server.copy(
                            healthStatus = if (nextFailures >= 3) ServerHealthStatus.UNHEALTHY.name else server.healthStatus,
                            failureCount = nextFailures,
                            lastCheckedAt = now
                        )
                    } else {
                        // WireGuard uses UDP; TCP refusal/timeout does not prove UDP is dead
                        server.copy(lastCheckedAt = now)
                    }
                }
            }
        }.awaitAll()

        if (updated.isNotEmpty()) {
            db.serverDao().upsertAll(updated)
        }
        reachableCount
    }

    suspend fun markServerVerified(server: VpnServerEntity, pingMs: Int, measuredSpeedBps: Long, countryCode: String?, countryName: String?) {
        db.serverDao().upsert(
            server.copy(
                pingMs = if (pingMs > 0) pingMs else server.pingMs,
                speedBps = if (measuredSpeedBps > 0) measuredSpeedBps else server.speedBps,
                countryCode = countryCode ?: server.countryCode,
                countryName = countryName ?: server.countryName,
                healthStatus = ServerHealthStatus.VERIFIED.name,
                successCount = server.successCount + 1,
                failureCount = 0,
                lastCheckedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun markServerFailed(server: VpnServerEntity) {
        val failures = server.failureCount + 1
        db.serverDao().upsert(
            server.copy(
                healthStatus = ServerHealthStatus.UNHEALTHY.name,
                failureCount = failures,
                lastCheckedAt = System.currentTimeMillis()
            )
        )
    }
}
