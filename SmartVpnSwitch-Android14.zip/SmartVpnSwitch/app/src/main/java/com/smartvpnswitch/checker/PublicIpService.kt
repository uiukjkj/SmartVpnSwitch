package com.smartvpnswitch.checker

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class IpInspectionResult(
    val ip: String,
    val countryCode: String?,
    val countryName: String?,
    val rttMs: Int,
    val throughputBps: Long
)

class PublicIpService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()
) {
    suspend fun fetchPublicIpAndGeo(): IpInspectionResult? = withContext(Dispatchers.IO) {
        val startNs = System.nanoTime()
        // Primary: ipwho.is (returns IP + reliable ISO country + measures real HTTPS response throughput)
        runCatching {
            val req = Request.Builder().url("https://ipwho.is/").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("HTTP ${resp.code}")
                val raw = resp.body?.string() ?: error("Empty body")
                val elapsedNs = (System.nanoTime() - startNs).coerceAtLeast(1_000_000L)
                val json = JSONObject(raw)
                if (!json.optBoolean("success", true)) error("Lookup unsuccessful")
                val ip = json.getString("ip")
                val cc = json.optString("country_code").takeIf { it.isNotBlank() }
                val cn = json.optString("country").takeIf { it.isNotBlank() }
                val bps = (raw.toByteArray().size.toLong() * 8_000_000_000L) / elapsedNs
                IpInspectionResult(
                    ip = ip,
                    countryCode = cc,
                    countryName = cn,
                    rttMs = (elapsedNs / 1_000_000L).toInt(),
                    throughputBps = bps
                )
            }
        }.getOrElse {
            // Fallback: api.ipify.org
            runCatching {
                val fbStart = System.nanoTime()
                val req = Request.Builder().url("https://api.ipify.org?format=json").build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) error("HTTP ${resp.code}")
                    val raw = resp.body?.string() ?: error("Empty body")
                    val elapsedNs = (System.nanoTime() - fbStart).coerceAtLeast(1_000_000L)
                    val ip = JSONObject(raw).getString("ip")
                    val bps = (raw.toByteArray().size.toLong() * 8_000_000_000L) / elapsedNs
                    IpInspectionResult(
                        ip = ip,
                        countryCode = null,
                        countryName = null,
                        rttMs = (elapsedNs / 1_000_000L).toInt(),
                        throughputBps = bps
                    )
                }
            }.getOrNull()
        }
    }
}
