package com.smartvpnswitch.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RuggedDarkColors = darkColorScheme(
    primary = Color(0xFFF59E0B),
    onPrimary = Color(0xFF111827),
    secondary = Color(0xFF10B981),
    onSecondary = Color(0xFF06281E),
    background = Color(0xFF090C10),
    onBackground = Color(0xFFF3F4F6),
    surface = Color(0xFF12171F),
    onSurface = Color(0xFFF3F4F6),
    surfaceVariant = Color(0xFF1B232E),
    onSurfaceVariant = Color(0xFF9CA3AF),
    error = Color(0xFFEF4444)
)

@Composable
fun SmartVpnTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = RuggedDarkColors,
        content = content
    )
}
