package com.smartvpnswitch.buttons

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.smartvpnswitch.SmartVpnApplication
import com.smartvpnswitch.controller.SmartVpnForegroundService
import com.smartvpnswitch.ui.MainActivity

/**
 * Invisible launcher trampoline assigned in 8849 Shark 3:
 * Settings -> Shortcut settings -> Func2 -> Long press.
 */
class Func2NextServerProxyActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as SmartVpnApplication
        val prepareIntent = app.vpnController.prepareVpnPermissionIntent()

        if (prepareIntent != null) {
            startActivity(
                Intent(this, MainActivity::class.java).apply {
                    putExtra(MainActivity.EXTRA_REQUEST_VPN_PERMISSION, true)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        } else {
            SmartVpnForegroundService.dispatchAction(
                applicationContext,
                SmartVpnForegroundService.ACTION_NEXT_SERVER
            )
            Toast.makeText(applicationContext, "Smart VPN: следующий сервер...", Toast.LENGTH_SHORT).show()
        }
        finishAndRemoveTask()
    }
}
