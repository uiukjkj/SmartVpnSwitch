package com.smartvpnswitch.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        VpnServerEntity::class,
        ConfigSourceEntity::class,
        ConnectionLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun serverDao(): VpnServerDao
    abstract fun sourceDao(): ConfigSourceDao
    abstract fun logDao(): ConnectionLogDao

    companion object {
        const val DEFAULT_VPNGATE_SOURCE_ID = "builtin_vpngate_csv"
        const val DEFAULT_VPNGATE_URL = "https://www.vpngate.net/api/iphone/"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "smart_vpn_switch.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
