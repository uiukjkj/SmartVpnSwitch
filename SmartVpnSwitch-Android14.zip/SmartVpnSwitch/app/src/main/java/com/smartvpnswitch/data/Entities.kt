package com.smartvpnswitch.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "vpn_servers",
    indices = [
        Index(value = ["sourceId"]),
        Index(value = ["protocol"]),
        Index(value = ["healthStatus"])
    ]
)
data class VpnServerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val host: String,
    val port: Int,
    val countryCode: String,
    val countryName: String,
    val protocol: String, // WIREGUARD | OPENVPN
    val sourceId: String,
    val encryptedConfig: String,
    val pingMs: Int = -1,
    val speedBps: Long = 0L,
    val uptimeMs: Long = 0L,
    val healthStatus: String = ServerHealthStatus.UNKNOWN.name,
    val failureCount: Int = 0,
    val successCount: Int = 0,
    val lastCheckedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "config_sources")
data class ConfigSourceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val url: String,
    val format: String, // VPNGATE_CSV | RAW_WIREGUARD_CONF | RAW_OPENVPN_OVPN | JSON_FEED
    val enabled: Boolean = true,
    val isBuiltIn: Boolean = false,
    val lastSyncedAt: Long = 0L,
    val lastError: String? = null,
    val serverCount: Int = 0
)

@Entity(tableName = "connection_logs")
data class ConnectionLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val level: String, // INFO | WARN | ERROR | SUCCESS
    val tag: String,
    val message: String
)
