package com.smartvpnswitch.controller

import android.content.Context
import android.content.Intent
import com.smartvpnswitch.checker.PublicIpService
import com.smartvpnswitch.checker.ServerProbe
import com.smartvpnswitch.data.AppDatabase
import com.smartvpnswitch.data.AppPreferences
import com.smartvpnswitch.data.ConnectionLogEntity
import com.smartvpnswitch.data.KeystoreCrypto
import com.smartvpnswitch.data.VpnProtocol
import com.smartvpnswitch.data.VpnServerEntity
import com.smartvpnswitch.discovery.ServerDiscoveryRepository
import com.smartvpnswitch.engine.OpenVpnAidlEngine
import com.smartvpnswitch.engine.VpnRuntimeState
import com.smartvpnswitch.engine.VpnStatus
import com.smartvpnswitch.engine.WireGuardEngine
import com.wireguard.android.backend.Tunnel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class SmartVpnController(
    private val context: Context,
    private val db: AppDatabase,
    private val prefs: AppPreferences,
    private val discoveryRepo: ServerDiscoveryRepository,
    private val serverProbe: ServerProbe,
    private val ipService: PublicIpService,
    val wireGuardEngine: WireGuardEngine,
    val openVpnEngine: OpenVpnAidlEngine
) {
    companion object {
        private const val MAX_FAILOVER_ATTEMPTS = 3
        private const val VERIFY_TIMEOUT_MS = 14_000L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val opMutex = Mutex()
    private var monitorJob: Job? = null
    private var userRequestedDisconnect = false

    private val _runtimeState = MutableStateFlow(VpnRuntimeState())
    val runtimeState: StateFlow<VpnRuntimeState> = _runtimeState.asStateFlow()

    suspend fun refreshPublicIpOutsideOrInside() {
        val res = ipService.fetchPublicIpAndGeo()
        if (res != null) {
            _runtimeState.value = _runtimeState.value.copy(publicIp = res.ip)
        }
    }

    fun prepareVpnPermissionIntent(): Intent? = wireGuardEngine.preparePermission()

    fun toggleVpn() {
        scope.launch {
            val current = _runtimeState.value.status
            if (current == VpnStatus.CONNECTED || current == VpnStatus.CONNECTING || current == VpnStatus.VERIFYING) {
                disconnect()
            } else {
                connectBestServer()
            }
        }
    }

    fun connectBestServer() {
        scope.launch {
            opMutex.withLock {
                userRequestedDisconnect = false
                connectWithFailover(excludeIds = emptySet())
            }
        }
    }

    fun connectSpecificServer(server: VpnServerEntity) {
        scope.launch {
            opMutex.withLock {
                userRequestedDisconnect = false
                connectWithFailover(forcedFirst = server, excludeIds = emptySet())
            }
        }
    }

    fun switchToNextServer() {
        scope.launch {
            opMutex.withLock {
                userRequestedDisconnect = false
                val currentId = _runtimeState.value.activeServer?.id
                disconnectInternal(logUserAction = false)
                val excluded = if (currentId != null) setOf(currentId) else emptySet()
                connectWithFailover(excludeIds = excluded)
            }
        }
    }

    fun disconnect() {
        scope.launch {
            opMutex.withLock {
                userRequestedDisconnect = true
                disconnectInternal(logUserAction = true)
            }
        }
    }

    private suspend fun disconnectInternal(logUserAction: Boolean) {
        monitorJob?.cancel()
        monitorJob = null
        wireGuardEngine.disconnect()
        openVpnEngine.disconnect()
        _runtimeState.value = _runtimeState.value.copy(
            status = VpnStatus.DISCONNECTED,
            activeServer = null,
            rxBytes = 0L,
            txBytes = 0L,
            statusDetail = "Отключено"
        )
        SmartVpnNotificationHelper.updateNotification(context, "Smart VPN Switch", "Отключено")
        if (logUserAction) {
            log("INFO", "VPN отключён")
        }
        refreshPublicIpOutsideOrInside()
    }

    private suspend fun connectWithFailover(
        forcedFirst: VpnServerEntity? = null,
        excludeIds: Set<String>
    ) {
        val tried = excludeIds.toMutableSet()
        var servers = db.serverDao().getAll()
        if (servers.isEmpty()) {
            _runtimeState.value = _runtimeState.value.copy(
                status = VpnStatus.CONNECTING,
                statusDetail = "Поиск серверов из источников..."
            )
            discoveryRepo.syncAllEnabledSources()
            serverProbe.probeServersBatch(limit = 20)
            servers = db.serverDao().getAll()
        }

        val openVpnInstalled = openVpnEngine.isOpenVpnInstalled()
        val preferWg = prefs.settings.value.preferWireGuard

        for (attempt in 1..MAX_FAILOVER_ATTEMPTS) {
            if (userRequestedDisconnect) return
            val candidate = if (attempt == 1 && forcedFirst != null) {
                forcedFirst
            } else {
                ServerSelector.pickBest(
                    servers = servers,
                    preferWireGuard = preferWg,
                    openVpnAvailable = openVpnInstalled,
                    excludeIds = tried
                )
            }

            if (candidate == null) {
                val errMsg = if (!openVpnInstalled && servers.any { it.protocol == VpnProtocol.OPENVPN.name }) {
                    "Нет подходящих серверов (для OpenVPN установите 'OpenVPN for Android')"
                } else {
                    "Нет доступных проверенных серверов"
                }
                _runtimeState.value = _runtimeState.value.copy(
                    status = VpnStatus.ERROR,
                    activeServer = null,
                    statusDetail = errMsg
                )
                log("ERROR", errMsg)
                return
            }

            tried.add(candidate.id)
            val connected = tryConnectAndVerify(candidate, attempt)
            if (connected) {
                prefs.setLastServerId(candidate.id)
                startConnectionMonitor(candidate)
                return
            }

            serverProbe.markServerFailed(candidate)
            disconnectInternal(logUserAction = false)
            delay(800L * attempt)
        }

        _runtimeState.value = _runtimeState.value.copy(
            status = VpnStatus.ERROR,
            activeServer = null,
            statusDetail = "Не удалось подключиться после $MAX_FAILOVER_ATTEMPTS попыток"
        )
        log("ERROR", "Превышен лимит попыток переподключения ($MAX_FAILOVER_ATTEMPTS)")
    }

    private suspend fun tryConnectAndVerify(server: VpnServerEntity, attempt: Int): Boolean {
        _runtimeState.value = _runtimeState.value.copy(
            status = VpnStatus.CONNECTING,
            activeServer = server,
            statusDetail = "Попытка #$attempt: подключение к ${server.name}..."
        )
        log("INFO", "Попытка #$attempt -> ${server.name} (${server.protocol})")

        val configPlain = runCatching { KeystoreCrypto.decrypt(server.encryptedConfig) }.getOrNull()
        if (configPlain == null) {
            log("ERROR", "Ошибка расшифровки конфига для ${server.name}")
            return false
        }

        val startResult = when (VpnProtocol.valueOf(server.protocol)) {
            VpnProtocol.WIREGUARD -> {
                if (wireGuardEngine.preparePermission() != null) {
                    log("ERROR", "Отсутствует системное разрешение VpnService")
                    return false
                }
                wireGuardEngine.connect(configPlain)
            }
            VpnProtocol.OPENVPN -> {
                openVpnEngine.connect(configPlain)
            }
        }

        if (startResult.isFailure) {
            log("WARN", "Ошибка запуска туннеля ${server.name}: ${startResult.exceptionOrNull()?.message}")
            return false
        }

        // Verify real tunnel establishment and real traffic inside tunnel
        _runtimeState.value = _runtimeState.value.copy(
            status = VpnStatus.VERIFYING,
            statusDetail = "Проверка реального туннеля (${server.name})..."
        )

        val deadline = System.currentTimeMillis() + VERIFY_TIMEOUT_MS
        var tunnelUp = false
        while (System.currentTimeMillis() < deadline && !userRequestedDisconnect) {
            tunnelUp = when (VpnProtocol.valueOf(server.protocol)) {
                VpnProtocol.WIREGUARD -> wireGuardEngine.tunnelState.value == Tunnel.State.UP
                VpnProtocol.OPENVPN -> openVpnEngine.state.value.level == "LEVEL_CONNECTED"
            }
            if (tunnelUp) break
            delay(400L)
        }

        if (!tunnelUp) {
            log("WARN", "Таймаут установления туннеля на ${server.name}")
            return false
        }

        val ipCheck = ipService.fetchPublicIpAndGeo()
        if (ipCheck == null) {
            log("WARN", "Туннель ${server.name} поднялся, но внешний HTTPS-трафик не проходит")
            return false
        }

        if (server.protocol == VpnProtocol.WIREGUARD.name) {
            val (rx, _) = wireGuardEngine.getTrafficStats()
            if (rx <= 0L) {
                log("WARN", "WireGuard handshake/RX=0 на ${server.name}")
                return false
            }
        }

        serverProbe.markServerVerified(
            server = server,
            pingMs = ipCheck.rttMs,
            measuredSpeedBps = ipCheck.throughputBps,
            countryCode = ipCheck.countryCode,
            countryName = ipCheck.countryName
        )
        val refreshed = db.serverDao().getById(server.id) ?: server
        _runtimeState.value = _runtimeState.value.copy(
            status = VpnStatus.CONNECTED,
            activeServer = refreshed,
            publicIp = ipCheck.ip,
            statusDetail = "Подключено: ${refreshed.name} (${ipCheck.ip})"
        )
        SmartVpnNotificationHelper.updateNotification(
            context,
            "VPN Подключён: ${refreshed.countryCode}",
            "${refreshed.name} · IP: ${ipCheck.ip}"
        )
        log("SUCCESS", "Подключено и проверено: ${refreshed.name}, IP=${ipCheck.ip}, RTT=${ipCheck.rttMs}ms")
        return true
    }

    private fun startConnectionMonitor(server: VpnServerEntity) {
        monitorJob?.cancel()
        monitorJob = scope.launch {
            while (isActive && !userRequestedDisconnect) {
                delay(4000L)
                val stillUp = when (VpnProtocol.valueOf(server.protocol)) {
                    VpnProtocol.WIREGUARD -> {
                        val (rx, tx) = wireGuardEngine.getTrafficStats()
                        _runtimeState.value = _runtimeState.value.copy(rxBytes = rx, txBytes = tx)
                        wireGuardEngine.tunnelState.value == Tunnel.State.UP
                    }
                    VpnProtocol.OPENVPN -> openVpnEngine.state.value.level == "LEVEL_CONNECTED"
                }

                if (!stillUp && !userRequestedDisconnect) {
                    log("WARN", "Потеряно соединение с ${server.name}")
                    if (prefs.settings.value.autoReconnect) {
                        opMutex.withLock {
                            if (!userRequestedDisconnect) {
                                serverProbe.markServerFailed(server)
                                connectWithFailover(excludeIds = setOf(server.id))
                            }
                        }
                    } else {
                        disconnectInternal(logUserAction = false)
                    }
                    break
                }
            }
        }
    }

    private suspend fun log(level: String, message: String) {
        db.logDao().insert(ConnectionLogEntity(level = level, tag = "VpnController", message = message))
    }
}
