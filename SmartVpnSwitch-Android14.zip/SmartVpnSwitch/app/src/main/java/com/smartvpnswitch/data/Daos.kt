package com.smartvpnswitch.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface VpnServerDao {
    @Query("SELECT * FROM vpn_servers ORDER BY CASE WHEN healthStatus = 'VERIFIED' THEN 0 WHEN healthStatus = 'REACHABLE' THEN 1 WHEN healthStatus = 'UNKNOWN' THEN 2 ELSE 3 END, CASE WHEN pingMs > 0 THEN pingMs ELSE 99999 END ASC, speedBps DESC")
    fun observeAll(): Flow<List<VpnServerEntity>>

    @Query("SELECT * FROM vpn_servers")
    suspend fun getAll(): List<VpnServerEntity>

    @Query("SELECT * FROM vpn_servers WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): VpnServerEntity?

    @Query("SELECT * FROM vpn_servers WHERE healthStatus != 'UNHEALTHY' ORDER BY failureCount ASC, CASE WHEN pingMs > 0 THEN pingMs ELSE 99999 END ASC, speedBps DESC")
    suspend fun getHealthyCandidates(): List<VpnServerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(servers: List<VpnServerEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(server: VpnServerEntity)

    @Query("DELETE FROM vpn_servers WHERE sourceId = :sourceId AND id NOT IN (:keepIds)")
    suspend fun deleteMissingForSource(sourceId: String, keepIds: List<String>)

    @Query("DELETE FROM vpn_servers WHERE sourceId = :sourceId")
    suspend fun deleteBySource(sourceId: String)

    @Query("DELETE FROM vpn_servers WHERE failureCount >= :maxFailures")
    suspend fun pruneBroken(maxFailures: Int = 4)
}

@Dao
interface ConfigSourceDao {
    @Query("SELECT * FROM config_sources ORDER BY isBuiltIn DESC, name ASC")
    fun observeAll(): Flow<List<ConfigSourceEntity>>

    @Query("SELECT * FROM config_sources WHERE enabled = 1")
    suspend fun getEnabled(): List<ConfigSourceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(source: ConfigSourceEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(source: ConfigSourceEntity)

    @Query("DELETE FROM config_sources WHERE id = :id AND isBuiltIn = 0")
    suspend fun deleteCustom(id: String)
}

@Dao
interface ConnectionLogDao {
    @Query("SELECT * FROM connection_logs ORDER BY timestamp DESC LIMIT 200")
    fun observeRecent(): Flow<List<ConnectionLogEntity>>

    @Insert
    suspend fun insert(log: ConnectionLogEntity)

    @Query("DELETE FROM connection_logs WHERE id NOT IN (SELECT id FROM connection_logs ORDER BY timestamp DESC LIMIT 250)")
    suspend fun trimOld()

    @Query("DELETE FROM connection_logs")
    suspend fun clearAll()
}
