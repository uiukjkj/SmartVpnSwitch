package com.smartvpnswitch.data

enum class VpnProtocol {
    WIREGUARD,
    OPENVPN
}

enum class ServerHealthStatus {
    UNKNOWN,
    REACHABLE,
    VERIFIED,
    UNHEALTHY
}

enum class SourceFormat {
    VPNGATE_CSV,
    RAW_WIREGUARD_CONF,
    RAW_OPENVPN_OVPN,
    JSON_FEED
}
